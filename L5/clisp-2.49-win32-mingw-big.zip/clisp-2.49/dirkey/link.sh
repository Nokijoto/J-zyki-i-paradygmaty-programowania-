${MAKE-make} clisp-module \
  CC="${CC}" CPPFLAGS="${CPPFLAGS}" CFLAGS="${CFLAGS}" \
  CLISP_LINKKIT="$absolute_linkkitdir" CLISP="${CLISP}"
NEW_FILES="dirkey.o"
NEW_LIBS="${NEW_FILES}"
NEW_MODULES='dirkey'
TO_LOAD='dirkey1'
TO_PRELOAD="preload.lisp"
