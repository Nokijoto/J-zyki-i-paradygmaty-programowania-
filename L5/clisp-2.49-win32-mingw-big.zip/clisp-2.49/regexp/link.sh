${MAKE-make} clisp-module \
  CC="${CC}" CPPFLAGS="${CPPFLAGS}" CFLAGS="${CFLAGS}" \
  CLISP_LINKKIT="$absolute_linkkitdir" CLISP="${CLISP}"
NEW_FILES='regexi.o libgnu_rx.a'
NEW_LIBS="${NEW_FILES}"
NEW_MODULES="regexp"
TO_LOAD='regexp'
TO_PRELOAD='preload.lisp'
